#pragma once
class Glow
{
public:
	void run();
};

extern Glow* glow;