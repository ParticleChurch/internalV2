#pragma once
class Zeusbot
{
};

extern Zeusbot* zeusbot;