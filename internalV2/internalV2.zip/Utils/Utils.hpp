#pragma once
#include "Logger.hpp"
#include "GetVFunc.hpp"
#include "VMT.hpp"
#include "PatternScan.hpp"
#include "StrHash.hpp"