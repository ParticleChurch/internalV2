#pragma once
class CRecvProxyData;
struct RecvTable_t;
struct DataVariant_t;
struct RecvProp_t;
struct RecvTable_t;

struct matrix3x4_t;
class Vector;

class Entity;