#pragma once
struct csurface_t
{
	const char* szName;
	short			nSurfaceProps;
	std::uint16_t	uFlags;
};